Simple PHP MVC framework.

php >= 5.6
