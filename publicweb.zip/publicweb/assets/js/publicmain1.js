/**
 * @RK Shrestha <rakesh.shrestha@gmail.com>
 */
var app = angular.module('WebApp', [
    'ngRoute'
]);

app.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
    .when("/", {templateUrl: "tplspublicpages/home", controller: "HomeCtrl"})

    .when("/project_structure", {templateUrl: "tplspublicpages/projectstructure", controller: "PageCtrl"})
    .when("/project_impacts_&_results", {templateUrl: "tplspublicpages/projectimpactsresults", controller: "PageCtrl"})
    .when("/project_components", {templateUrl: "tplspublicpages/projectcomponents", controller: "PageCtrl"})

    .when("/implementation_arrangements", {templateUrl: "tplspublicpages/implementationarrangements", controller: "PageCtrl"})
    .when("/project_organizations", {templateUrl: "tplspublicpages/projectorganizations", controller: "PageCtrl"})

    .when("/project_factsheets", {templateUrl: "tplspublicpages/projectfactsheets", controller: "PageCtrl"})

    .when("/notices", {templateUrl: "tplspublicpages/newsdigest", controller: "PageCtrl"})

    .when("/documents", {templateUrl: "tplspublicpages/documents", controller: "DocsCtrl"})
    .when('/documents/:catId', {
        templateUrl: function (urlattr) {
            return 'tplspublicpages/documents/' + urlattr.catId;
        },
        controller: 'DocsCtrl'
    })
    
    .when("/photo_gallery", {templateUrl: "tplspublicpages/photogallery", controller: "PageCtrl"})
    
    .when("/related_links", {templateUrl: "tplspublicpages/relatedlinks", controller: "PageCtrl"})

    .when("/contact", {templateUrl: "tplspublicpages/contact", controller: "ContactCtrl"})

    .otherwise("/", {templateUrl: "tplspublicpages/home", controller: "HomeCtrl"});
}]);

app.controller('HomeCtrl', function ($scope /* , $location, $http */) {
    var map;
    var mzoom = 7;
    var mlat = 28.2668900;
    var mlong = 83.9685100;

    var myOptions = {
        center: new google.maps.LatLng(mlat, mlong),
        zoom: mzoom,
        mapTypeId: google.maps.MapTypeId.hybrid,
        disableDefaultUI: true,
        zoomControl: true,
        zoomControlOptions: {
            position: google.maps.ControlPosition.LEFT_TOP
        }
    };

    map = new google.maps.Map(document.getElementById("mapibasline"), myOptions);
    var infoWin = new google.maps.InfoWindow();

    var nepalData = new google.maps.Data();
    nepalData.loadGeoJson("assets/nepalprovinces.geojson", {idPropertyName: "Name"});
    nepalData.setStyle({
        strokeColor: "#660000",
        strokeOpacity: 0.8,
        strokeWeight: 1.5,
        fillColor: "#FFFFFF",
        fillOpacity: 0
    });
    nepalData.setMap(map);

    var projectData = new google.maps.Data();
    projectData.loadGeoJson("assets/rudpprojects.geojson", {idPropertyName: "Name"});
    projectData.setStyle({
        strokeColor: "#000055",
        strokeOpacity: 0.8,
        strokeWeight: 1.5,
        fillColor: "#FFFFFF",
        fillOpacity: 0
    });
    projectData.addListener('click', function (event) {
        document.getElementById('mouse_detail').textContent = event.feature.getProperty('Name');
    });
    projectData.setMap(map);

    var styleControl = document.getElementById('style-selector-control');
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(styleControl);

    $scope.changemap = function (id) {
        if (id == 1) {
            var gCenter = new google.maps.LatLng(27.01434, 84.88572);
            var gZoomLevel = 13;
        }
        if (id == 2) {
            var gCenter = new google.maps.LatLng(26.45244, 87.27415);
            var gZoomLevel = 12;
        }
        if (id == 3) {
            var gCenter = new google.maps.LatLng(28.05607, 81.62802);
            var gZoomLevel = 13;
        }
        if (id == 4) {
            var gCenter = new google.maps.LatLng(27.50125, 83.44452);
            var gZoomLevel = 13;
        }
        map.setCenter( gCenter );
        map.panTo( gCenter  );
        map.setZoom( gZoomLevel );        
        
    };

});

app.controller('ContactCtrl', function (/* $scope, $location, $http */) {
    $("#feedbackform").submit(function (e) {
        var postData = $(this).serializeArray();
        var formURL = $(this).attr("action");
        $.ajax({
            url: formURL,
            type: "POST",
            data: postData,
            success: function (data, textStatus, jqXHR)
            {
                $('#feedbackform').html(data);
            }
        });
        e.preventDefault(); //STOP default action
        e.unbind(); //unbind. to stop multiple form submit.
    });
    
    var map;
    var markers = [
        {
            "title": 'Kailali',
            "lat": '28.831354',
            "lng": '80.898651',
            "description": '<p>Regional Project Implementation Unit, Kailali<br />Tel. 091-521157 / 520729<br />e-mail:&nbsp; <a href="mailto:rpiudhangadi@gmail.com">rpiudhangadi@gmail.com</a></p>'
        },
        {
            "title": 'Birgunj',
            "lat": '27.005915',
            "lng": '84.859085',
            "description": '<p>Birgunj, PIUs<br />Tel. 051-525185/ 522802<br />email: <a href="mailto:rudp.birganjsubmetro@gmail.com">rudp.birganjsubmetro@gmail.com</a></p>'
        },
        {
            "title": 'Siddharthanagar',
            "lat": '27.5065',
            "lng": '83.4377',
            "description": '<p>Siddharthanagar, PIUs<br />Tel: 071-52255/ 520292/ 523560/071520908<br />email: <a href="mailto:rudp.siddharthanagar@gmail.com">rudp.siddharthanagar@gmail.com</a></p>'
        },
        {
            "title": 'Biratnagar',
            "lat": '26.4831',
            "lng": '87.28337',
            "description": '<p>Biratnagar, PIUs<br />Tel: 012-524579/091-520729<br />e-mail: <a href="mailto:stiueip.brt@gmail.com">stiueip.brt@gmail.com</a></p>'
        },
        {
            "title": 'Nepalgunj',
            "lat": '28.05',
            "lng": '81.61667',
            "description": '<p>Nepalgunj, PIUs<br />Tel: 081-526199/527919/<br />e-mail: <a href="mailto:rudp.nepalgunj@gmail.com">rudp.nepalgunj@gmail.com</a></p>'
        },
        {
            "title": 'Bheemdutt',
            "lat": '28.987280',
            "lng": '80.165184',
            "description": '<p>Bheemdutt, PISUs<br />Tel: 099-521322/521167</p>'
        },
        {
            "title": 'Dhangadi',
            "lat": '28.683359',
            "lng": '80.608063',
            "description": '<p>Dhangadi, PISUs<br />Tel: 091-420429/520729<br />e-mail: <a href="mailto:dhangadhimun2013@gmail.com">dhangadhimun2013@gmail.com</a></p>'
        },
        {
            "title": 'Sukalaphanta',
            "lat": '28.8554',
            "lng": '80.2544',
            "description": '<p>Sukalaphanta, PISUs<br />Tel : 099540010<br />e-mail: <a href="mailto:info@shuklaphantamun.gov.np">info@shuklaphantamun.gov.np</a></p>'
        },
        {
            "title": 'Godawari',
            "lat": '29.51666667',
            "lng": '80.98333333',
            "description": '<p>Godawari, PISUs<br />Tel: 091-551305<br />e-mail: <a href="mailto:mungodawari@gmail.com">mungodawari@gmail.com</a></p>'
        }
    ];
    
    function initMap() {
        var mapOptions = {
            center: new google.maps.LatLng(markers[0].lat, markers[0].lng),
            zoom: 8,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true,
            zoomControl: true,
            zoomControlOptions: {
            position: google.maps.ControlPosition.LEFT_TOP
        }
        };
        var infoWindow = new google.maps.InfoWindow();
        var latlngbounds = new google.maps.LatLngBounds();
        var map = new google.maps.Map(document.getElementById("map"), mapOptions);

        for (var i = 0; i < markers.length; i++) {
            var data = markers[i]
            var myLatlng = new google.maps.LatLng(data.lat, data.lng);
            var marker = new google.maps.Marker({
                position: myLatlng,
                map: map,
                title: data.title
            });
            (function (marker, data) {
                google.maps.event.addListener(marker, "click", function (e) {
                    infoWindow.setContent("<div style = 'width:200px;min-height:40px'>" + data.description + "</div>");
                    infoWindow.open(map, marker);
                });
            })(marker, data);
            latlngbounds.extend(marker.position);
        }
        var bounds = new google.maps.LatLngBounds();
        map.setCenter(latlngbounds.getCenter());
        map.fitBounds(latlngbounds);
    }
    
    initMap();

});

app.controller('PageCtrl', function (/* $scope, $location, $http */) {
});

app.controller('DocsCtrl', function (/* $scope, $location, $http */) {
    
});
