<footer>
    <div class="container">
        <hr>
        <div class="pull-left">
            Department of Urban Development & Building Construction<br>
            Regional Urban Development Project<br>
            Babar Mahal, Kathmandu, Nepal<br>
            Tel: 977-1-4262969/4262535<br>
            Fax: 977-1-4262729<br>
            Email: 
        </div>
        <div class="pull-right">
            <p>RUDP © <?php echo date('Y') ?>. All rights reserved. </p>
        </div>

    </div>
</footer>