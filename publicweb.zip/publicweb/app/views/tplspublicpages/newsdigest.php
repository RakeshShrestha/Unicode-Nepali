<div class="container sectionfirst">

    <div class="row">

        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><a href="#/">Home</a>
                </li>
                <li class="active">Notices</li>
            </ol>
        </div>

    </div>
    <?php
    foreach ($contents as $content) {
        ?>
        <div class="row">

            <div class="col-md-1">
            </div>
            <div class="col-md-5">
                <img src="uploads/news/<?php echo $content->docslink; ?>" class="img-responsive">
            </div>
            <div class="col-md-6">
                <h3><a><?php echo $content->docstitle; ?></a>
                </h3>
                <?php echo $content->docsdescription; ?>
            </div>

        </div>
        <br>
        <?php
    }
    ?>

    <div class="row">

        <!--ul class="pager">
            <li class="previous"><a>&larr; Older</a>
            </li>
            <li class="next"><a>Newer &rarr;</a>
            </li>
        </ul-->

    </div>

</div>
<!-- /.container -->