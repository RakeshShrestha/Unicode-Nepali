<!-- Page Content -->
<style>
    .panel-body {
        padding: 0px !important;
    }
</style>
<script>
    $(document).ready(function () {
        var pgwSlider = $('.pgwSlider').pgwSlider();
        pgwSlider.reload({
            maxHeight: 410,
            intervalDuration: 4000,
            displayControls: true,
            verticalCentering: true,
            adaptiveHeight: true,
            listPosition: 'left',
            transitionEffect: 'sliding',
            displayList: false
        });
    });
</script>
<div class="container sectionfirst">

    <div class="row">
        <div class="col-md-4">

            <div class="panel panel-default"> 
                <div class="panel-heading"> Overview </div> 
                <div class="panel-body" style="padding: 5px !important"> 
                    <?php echo mb_str_replace('<img ', '<img class="img-responsive" ', $content); ?>
                </div> 
            </div>
            
        </div>
        <div class="col-md-8">
            <div class="panel panel-default"> 
                <div class="panel-heading"> Recent Images </div> 
                <div class="panel-body"> 
                    <ul class="pgwSlider">
                        <?php
                        $i = 1;
                        foreach ($images as $image) {
                            ?>
                            <li>
                                <img src="uploads/gallery/<?php echo $image->docslink; ?>">
                                <span><?php echo $image->docstitle; ?></span>
                            </li>
                            <?php
                            $i++;
                        }
                        ?>
                    </ul>
                </div> 
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-md-9">
            <style>
                .info-box {
                    /*margin:-150px -300px -300px -300px;*/
                    margin-left: -230px;
                    margin-top: -70px;
                    border: 1px solid #eee;
                    background: #fff;
                    box-shadow: 3px 4px 6px rgba(0,0,0,0.4);
                    padding: 3px;
                    font-weight: bolder;
                    position: absolute;
                    z-index: 5000;
                }
                .map-control {
                    font-family: 'Roboto','sans-serif';
                    margin: 10px;
                    float: right;
                    right: 0px;
                    /* Hide the control initially, to prevent it from appearing
                    before the map loads. */
                    display: none;
                    top:35px !important;
                }
                /* Display the control once it is inside the map. */
                #mapibasline .map-control { display: block; float: right; }
                .selector-control {
                    font-size: 14px;
                    line-height: 30px;
                    padding-left: 0px;
                    padding-right: 0px;
                    float: right;
                }
            </style>

            <div class="panel panel-default"> 
                <div class="panel-heading"> Project Mapping </div> 

                <div class="panel-body"> 

                    <div id="mapibasline" style="width:100%;height:405px;"></div>
                    <div id="mouse_detail"></div>
                    <div id="style-selector-control"  class="map-control pull-right">
                        <select id="style-selector" class="selector-control" ng-change="changemap(myval)" data-ng-model="myval">
                            <option value="">Select Site</option>
                            <option value="1">Morang</option>
                            <option value="2">Parsa</option>
                            <option value="3">Rupandehi</option>
                            <option value="4">Banke</option>
                        </select>
                    </div>
                </div> 

                <div class="panel-footer">The above map is for informative purpose and should not be considered authoritative for any kind of boundry demarcations.</div> 

            </div>            

        </div>
        <div class="col-md-3">

            <div class="panel panel-default"> 
                <div class="panel-heading"> Project Director </div> 
                <div class="panel-body" style="padding-left: 35px !important"> 
                    <img class="img-responsive" src="assets/img/profile-icon1.png" style="max-width: 170px">
                </div> 
                <div class="panel-footer"><!-- Chakrabarty, Kantha --></div> 
            </div>

            <div class="panel panel-default"> 
                <div class="panel-heading"> Information Officer </div> 
                <div class="panel-body" style="padding-left: 35px !important"> 
                    <img class="img-responsive" src="assets/img/profile-icon2.png" style="max-width: 170px">
                </div> 
                <div class="panel-footer"><!-- Manandhar, Pratigya --></div> 
            </div>

        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /.container -->
