<style>
    .side-bar a {
        background-color: #eee;
        border-bottom: 1px solid #fff !important;
    }
</style>
<script>
    $(document).ready(function () {
        $('#doclist').DataTable();
    });
</script>
<div class="container sectionfirst">

    <div class="row">

        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><a href="#/">Home</a>
                </li>
                <li class="active">Documents</li>
            </ol>
        </div>

    </div>
    <div class="row">

        <div class="col-md-3">

            <ul side-navigation class="nav side-bar" id="side-menu">

                <li><a href="#/documents/11">NPR</a></li>
                <li><a href="#/documents/12">QPR</a></li>
                <li><a href="#/documents/13">Annual</a></li>

                <li><a href="#/documents/21">Social Safeguard</a></li>
                <li><a href="#/documents/22">Environment Safeguard</a></li>

                <li><a href="#/documents/31">Planning Report</a></li>                    
                <li><a href="#/documents/32">EIA, IEE</a></li>

            </ul>

        </div>
        <div class="col-md-9">

            <div class="panel panel-default"> 
                <div class="panel-heading"> Documents List </div> 
                <!-- /.panel-heading --> 
                <div class="panel-body"> 
                    <div class="table-responsive"> 

                        <table id="doclist" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Document</th>
                                    <th>Date</th>
                                    <th>Download</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($contents as $content) {
                                    ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><?php echo $content->docstitle; ?></td>
                                        <td><?php echo mb_substr($content->submitdate, 0, 10); ?></td>
                                        <td><a href="home/docdwld/<?php echo $content->id; ?>"><i class="fa fa-download"> </i></a></td>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>SN</th>
                                    <th>Document</th>
                                    <th>Date</th>
                                    <th>Download</th>
                                </tr>
                            </tfoot>
                        </table>                        
                    </div> 

                    <!-- /.table-responsive --> 
                </div> 
                <!-- /.panel-body --> 
            </div>            
        </div>
    </div>

</div>
<!-- /.container -->