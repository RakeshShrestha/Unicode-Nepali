<nav class="navbar navbar-inverse" role="navigation">
    <div class="logocontainer"><center><img class="img-responsive" src="<?php echo getUrl('assets/img/headerlogo.png') ?>"></center></div>
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="<?php echo getUrl('') ?>#/">Home</a>
                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown">About RUDP <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo getUrl('') ?>#/project_structure">Project Structure</a></li>
                        <li><a href="<?php echo getUrl('') ?>#/project_impacts_&_results">Project Impacts & Results</a></li>
                        <li><a href="<?php echo getUrl('') ?>#/project_components">Project Components</a></li>
                        <li><a href="<?php echo getUrl('') ?>#/implementation_arrangements">Implementation Arrangements</a></li>
                        <li><a href="<?php echo getUrl('') ?>#/project_organizations">Project Organizations</a></li>
                    </ul>
                </li>

                <?php
                /*
                 <!--li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown">Project Implementation <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                    </ul>
                </li-->
                */
                ?>

                <li><a href="<?php echo getUrl('') ?>#/project_factsheets">Project Factsheets</a></li>
                
                <li><a href="<?php echo getUrl('') ?>#/notices">Notices</a></li>
                
                <li><a href="<?php echo getUrl('') ?>#/documents">Documents</a></li>
                
                <li><a href="<?php echo getUrl('') ?>#/photo_gallery">Photo Gallery</a></li>
                
                <li><a href="<?php echo getUrl('') ?>#/related_links">Related Links</a></li>
                
                <?php
                /*
                <!--li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown">News & Notice <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo getUrl('') ?>#/photo_gallery">Photo Gallery</a>
                        </li>
                        <li><a href="<?php echo getUrl('') ?>#/documents">Documents/Reports</a>
                        </li>
                        <li><a href="<?php echo getUrl('') ?>#/news_digest">News Digest</a>
                        </li>
                    </ul>
                </li-->
                */
                ?>
                
                <li><a href="<?php echo getUrl('') ?>#/contact">Feedback</a></li>

                <li><a href="<?php echo getUrl('manage/login') ?>" target="loginwin">Login</a></li>

            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>