<!-- Page Content -->
<div class="container sectionfirst">

    <div class="row">

        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><a href="#/">Home</a></li>
                <li class="active">Contact</li>
            </ol>
        </div>

    </div>
    <!-- /.row -->

    <div class="row">

        <div class="col-lg-9">
            <?php echo $content ?>
        </div>

        <div class="col-lg-3">
            <h4>Feedback</h4>

            <form role="form" id="feedbackform" method="POST" action="<?php echo getUrl('home/feedback') ?>">
                <div class="row">
                    <div class="form-group col-lg-12">
                        <label for="input1">Name</label>
                        <input type="text" name="contact_name" class="form-control" id="contact_name" required maxlength="150" pattern="[a-zA-Z ]+">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="input2">Email</label>
                        <input type="email" name="contact_email" class="form-control" id="contact_email" required maxlength="150">
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="input3">Phone</label>
                        <input type="phone" name="contact_phone" class="form-control" id="contact_phone" required pattern="\d*">
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-lg-12">
                        <label for="input4">Message</label>
                        <textarea name="contact_message" class="form-control" rows="6" id="contact_message" maxlength="350"></textarea>
                    </div>
                    <div class="form-group col-lg-12">
                        <input type="hidden" name="save" value="contact">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="col-lg-12">
            <br>
            <style>
                .info-box {
                    /*margin:-150px -300px -300px -300px;*/
                    margin-left: -230px;
                    margin-top: -70px;
                    border: 1px solid #eee;
                    background: #fff;
                    box-shadow: 3px 4px 6px rgba(0,0,0,0.4);
                    padding: 3px;
                    font-weight: bolder;
                    position: absolute;
                    z-index: 5000;
                }
                .map-control {
                    font-family: 'Roboto','sans-serif';
                    margin: 10px;
                    float: right;
                    right: 0px;
                    /* Hide the control initially, to prevent it from appearing
                    before the map loads. */
                    display: none;
                    top:35px !important;
                }
                /* Display the control once it is inside the map. */
                #mapibasline .map-control { display: block; float: right; }
                .selector-control {
                    font-size: 14px;
                    line-height: 30px;
                    padding-left: 0px;
                    padding-right: 0px;
                    float: right;
                }
            </style>
            <div id="map" style="width:100%;height:500px;"></div>
            <div id="mouse_detail"></div>
        </div>

    </div>
    <!-- /.row -->

</div><!-- /.container -->
