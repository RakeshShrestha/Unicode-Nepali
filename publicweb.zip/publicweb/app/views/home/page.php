<div class="container sectionfirst">

    <div class="row">

        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><a href="#/">Home</a>
                </li>
                <li class="active"><?php echo mb_ucwords(mb_str_replace(array('_', 'text'), ' ', $pagetile)) ?></li>
            </ol>
        </div>

    </div>

    <div class="row">

        <div class="col-lg-12">

            <?php echo $content ?>

        </div>

        <!--div class="col-lg-4">
            <div class="col-lg-12" style="background-color: #8BA2CB"> 
                <?php
                $db = DB::getContext();

                $sql = "SELECT * FROM cms_docs ORDER BY id DESC LIMIT 2";
                $stmt = $db->prepare($sql);
                $stmt->execute();

                $ndocs = $stmt->fetchAll();

                foreach ($ndocs AS $ndoc) {
                    ?>
                    <br>
                    <a href="#/" onclick="window.open('uploads/documents/<?php echo $ndoc->docslink; ?>', '_blank', 'toolbar=0,location=0,menubar=0');
                            return false;"><?php echo mb_str_replace('<img ', '<img class="img-responsive" ', $ndoc->docsdescription); ?></a>
                    <br>
                    <?php
                }
                ?>
            </div>
        </div-->
    </div>

</div>
<!-- /.container -->