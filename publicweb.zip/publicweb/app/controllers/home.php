<?php

final class cHome extends cController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $data['pagetitle'] = SITE_TITLE;
        $this->res->display($data);
    }

    public function admin_index() {
        if (getCurrentUserType() != 'superadmin') {
            $this->res->redirect('manage/login', 'Invalid Access');
        }
        $data['pagetitle'] = SITE_TITLE;
        $this->res->display($data);
    }

    public function docdwld($id = 1) {
        $mdoc = new model('cms_docs');
        $mdoc->select('*', 'id=?', $id);
        
        $filename = $mdoc->docsname;
        $readfilename = $mdoc->docslink;

        header("Content-disposition: attachment; filename=$filename");
        header("Content-type: application/pdf");
        readfile("uploads/documents/" . $readfilename);
    }

    public function feedback() {
        if ($this->req->isPost()) {
            $mail = new Email();
            $mail->setFrom(SYSTEM_EMAIL, 'Feedback Form');
            $mail->setTO(SYSTEM_EMAIL, 'DUDBC Admin');
            $mail->setCC(SYSTEM_EMAIL2, 'DUDBC');
            $mail->setSubject('Feedback');

            /* XSS Prevent */
            $_POST = array_map_recursive("cleanHtml", $_POST);

            $message = "Got feedback on dated " . date('Y-m-d H:i:s') . " from ip " . getRequestIP() . "\r\n\r\n";
            $message .= "Details:\r\n Name: " . $_POST['contact_name'] . "\r\n Email: " . $_POST['contact_email'] . "\r\n ";
            $message .= "Phone: " . $_POST['contact_phone'] . "\r\n Email: \r\n\r\n" . $_POST['contact_message'] . "\r\n ";

            $mail->setMessage($message);

            $mail->send();

            echo 'Feedback sent successfully';
        }
    }

}
