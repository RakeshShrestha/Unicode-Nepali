<?php

final class cTplsPublicPages extends cController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        exit();
    }

    public function header() {
        $data['layout'] = false;
        $this->res->display($data);
    }

    public function footer() {
        $data['layout'] = false;
        $this->res->display($data);
    }

    public function home() {
        $data['layout'] = false;
        $data['content'] = getContentByPageName('home');

        $db = DB::getContext();

        $sql = "SELECT * FROM cms_photos ORDER BY id DESC LIMIT " . PAGINATE_PUBLICLIMIT;
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['images'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function projectstructure() {
        $data['layout'] = false;
        $data['pagetile'] = 'project_structure';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function projectimpactsresults() {
        $data['layout'] = false;
        $data['pagetile'] = 'project_impacts_&_results';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function projectcomponents() {
        $data['layout'] = false;
        $data['pagetile'] = 'project_components';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function implementationarrangements() {
        $data['layout'] = false;
        $data['pagetile'] = 'implementation_arrangements';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function projectorganizations() {
        $data['layout'] = false;
        $data['pagetile'] = 'project_organizations';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function projectfactsheets() {
        $data['layout'] = false;
        $data['pagetile'] = 'project_factsheets';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }
    public function newsdigest() {
        $data['layout'] = false;

        $db = DB::getContext();

        $sql = "SELECT * FROM cms_news ORDER BY id DESC LIMIT " . PAGINATE_PUBLICLIMIT;
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function documents($cat = 0) {
        $data['layout'] = false;

        $db = DB::getContext();

        if ($cat != 0) {
            $sql = "SELECT * FROM cms_docs WHERE status=1 AND category='$cat' ORDER BY id DESC LIMIT " . PAGINATE_PUBLICLIMIT;
        } else {
            $sql = "SELECT * FROM cms_docs WHERE status=1 ORDER BY id DESC LIMIT " . PAGINATE_PUBLICLIMIT;
        }
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function photogallery() {
        $data['layout'] = false;

        $db = DB::getContext();

        $sql = "SELECT * FROM cms_photos ORDER BY id DESC LIMIT " . PAGINATE_PUBLICLIMIT;
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function relatedlinks() {
        $data['layout'] = false;
        $data['pagetile'] = 'related_links';
        $data['content'] = getContentByPageName($data['pagetile']);
        $this->res->display($data, 'home/page');
    }

    public function contact() {
        $data['layout'] = false;
        $data['content'] = getContentByPageName('contact');
        $this->res->display($data);
    }

}
