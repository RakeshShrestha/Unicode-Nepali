<?php

final class cLogin extends cController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $data = array();
        $data['username'] = '';
        $data['user'] = '';

        if (getCurrentUserType() == 'superadmin') {
            $this->res->redirect('admin');
        }
        if (getCurrentUserType() == 'user') {
            $this->res->redirect('dashboard');
        }

        $user = new user();

        if ($this->req->isPost()) {
            $username = $_POST['username'];
            $password = md5($_POST['password']);

            $user->select('*', 'username=?', $username);

            if (!$user->exist()) {
                $this->res->redirect('manage/login/' . $username, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">LOGIN FAILED!</div>');
            }
            if ($password != $user->password) {
                $this->res->redirect('manage/login/' . $username, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">WRONG PASSWORD!</div>');
            }
            if (!$user->status == 3) {
                $this->res->redirect('manage/login/' . $username, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">LOGIN FAILED!</div>');
            }

            setCurrentUser($user->get());

            if (getCurrentUserType() == 'superadmin') {
                $this->res->redirect('admin');
            }
            if (getCurrentUserType() == 'user') {
                $this->res->redirect('dashboard');
            }

            $data['username'] = $username;
            $data['user'] = $user;
        }

        $this->res->display($data, 'main/login_form');
    }

}
