<?php

final class cMain extends cAdminController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $data['pagetitle'] = SITE_TITLE;
        $this->res->display($data);
    }

    public function admin_myprofile() {
        $data['pagename'] = 'Welcome';

        $user = new user(getCurrentUserID());

        if ($this->req->isPost()) {
            $vars = $_POST;
            if ($vars['password']) {
                $vars['password'] = md5($vars['password']);
            } else {
                $vars['password'] = $user->password;
            }

            $user->assign($vars, true);
            $user->update();

            $this->res->redirect('admin/main/myprofile', '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Profile Updated Successfully</div>');
        }

        $data['authuser'] = $user;

        $this->res->display($data);
    }

    public function admin_users() {
        $data['pagename'] = 'Welcome';

        $db = DB::getContext();

        $stmt = $db->prepare("SELECT * FROM users WHERE perms='user' ORDER BY created DESC");
        $stmt->execute();

        $data['users'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function admin_disable($userid = 0) {
        $data['pagename'] = 'Welcome';

        $db = DB::getContext();

        $stmt = $db->prepare("UPDATE users SET status='3' WHERE id=? ");
        $stmt->bindValue(1, $userid);
        $stmt->execute();

        $this->res->redirect('admin/main/users', 'User Disabled');
    }

    public function admin_enable($userid = 0) {
        $data['pagename'] = 'Welcome';

        $db = DB::getContext();

        $stmt = $db->prepare("UPDATE users SET status='2' WHERE id=? ");
        $stmt->bindValue(1, $userid);
        $stmt->execute();

        $this->res->redirect('admin/main/users', 'User Enabled');
    }

    public function admin_contentlist($page_number = 1) {
        $data['pagename'] = 'Manage Contents';

        $db = DB::getContext();


        $stmt = $db->prepare("SELECT COUNT(*) AS numrows FROM cms_pages ");
        $stmt->execute();
        $content = $stmt->fetch();

        $totalrows = $content->numrows;

        $total_pages = ceil($totalrows / PAGINATE_LIMIT);
        $page_position = (($page_number - 1) * PAGINATE_LIMIT); //get starting position to fetch the records

        $cpage = $this->req->getCurrentPage();

        $data['paginatelink'] = paginate($page_number, $totalrows, $total_pages, 'admin/main/contentlist');
        $data['pagenumber'] = $page_number;

        $sql = "SELECT * FROM cms_pages ORDER BY id LIMIT $page_position, " . PAGINATE_LIMIT;
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function admin_contentedit($cid = 0) {
        $data['pagename'] = 'Manage Dashboard Content';

        $db = DB::getContext();

        if ($this->req->isPost()) {
            $stmt = $db->prepare("UPDATE cms_pages SET pagecontent=? WHERE id=? ");
            $stmt->bindValue(1, $_POST['dashboard_content']);
            $stmt->bindValue(2, $cid);
            $stmt->execute();

            $this->res->redirect('admin/main/contentedit/' . $cid, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Content Updated Successfully</div>');
        }

        $stmt = $db->prepare("SELECT * FROM cms_pages WHERE id=? ");
        $stmt->bindValue(1, $cid);
        $stmt->execute();

        $content = $stmt->fetch();

        if ($content) {
            $data['content'] = $content->pagecontent;
            $data['content_name'] = mb_ucwords(mb_str_replace(array('_', 'text'), ' ', $content->pagename));
            $data['content_id'] = $content->id;

            $this->res->display($data);
        } else {
            $this->res->redirect('admin/main/contentlist');
        }
    }

    public function ajax_userexist() {
        $db = DB::getContext();

        $stmt = $db->prepare("SELECT username FROM users WHERE username=?");
        $stmt->bindValue(1, $_POST['username']);

        $stmt->execute();

        echo $stmt->rowCount();
    }

    public function ajax_userexist_account() {
        $db = DB::getContext();

        $stmt = $db->prepare("SELECT username FROM users WHERE username = ? and id <> ?");
        $stmt->bindValue(1, $_POST['username']);
        $stmt->bindValue(2, $_POST['id']);

        $stmt->execute();

        echo $stmt->rowCount();
    }

    public function logout() {
        setCurrentUser();

        $this->res->redirect('manage/login', '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">You have logged out!</div>');
    }

}
