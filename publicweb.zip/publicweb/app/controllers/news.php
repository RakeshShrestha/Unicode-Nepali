<?php

final class cNews extends cAdminController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $data['pagetitle'] = SITE_TITLE;
        $this->res->display($data);
    }

    public function admin_contentlist($page_number = 1) {
        $data['pagename'] = 'Manage Notices';

        $db = DB::getContext();

        $stmt = $db->prepare("SELECT COUNT(*) AS numrows FROM cms_news ");
        $stmt->execute();
        $content = $stmt->fetch();

        $totalrows = $content->numrows;

        $total_pages = ceil($totalrows / PAGINATE_LIMIT);
        $page_position = (($page_number - 1) * PAGINATE_LIMIT); //get starting position to fetch the records

        $cpage = $this->req->getCurrentPage();

        $data['paginatelink'] = paginate($page_number, $totalrows, $total_pages, 'admin/news/contentlist');
        $data['pagenumber'] = $page_number;

        $sql = "SELECT * FROM cms_news ORDER BY id DESC LIMIT $page_position, " . PAGINATE_LIMIT;
        $stmt = $db->prepare($sql);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function admin_contentadd($pno = 1) {
        $data['pagename'] = 'Manage Notices';
        $data['pno'] = $pno;

        if ($this->req->isPost()) {
            $db = DB::getContext();

            $uploadedfilename = "";

            if (isset($_FILES['document'])) {
                $d['file_name'] = $_FILES['document']['name'];
                $d['file_size'] = $_FILES['document']['size'];
                $d['file_tmp'] = $_FILES['document']['tmp_name'];
                $d['file_type'] = $_FILES['document']['type'];
                $d['file_ext'] = pathinfo($d['file_name'], PATHINFO_EXTENSION);

                if (is_uploaded_file($d['file_tmp'])) {
                    $uploadedfilename = mb_str_replace("-", "", genGUID()) . "." . $d['file_ext'];
                    move_uploaded_file($d['file_tmp'], "uploads/news/" . $uploadedfilename);

                    $stmt = $db->prepare("INSERT INTO cms_news(docstitle, docsdescription, docsname, docslink, status) VALUES(?, ?, ?, ?, ?) ");
                    $stmt->bindValue(1, $_POST['docstitle']);
                    $stmt->bindValue(2, $_POST['docsdescription']);
                    $stmt->bindValue(3, $d['file_name']);
                    $stmt->bindValue(4, $uploadedfilename);
                    $stmt->bindValue(5, 0);
                    $stmt->execute();
                }
            }
            $this->res->redirect('admin/news/contentadd/', '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Notices added Successfully</div>');
        }
        $this->res->display($data);
    }

    public function admin_contentedit($cid = 0) {
        $data['pagename'] = 'Manage Notices';

        $db = DB::getContext();

        if ($this->req->isPost()) {
            $uploadedfilename = "";

            $stmt = $db->prepare("UPDATE cms_news SET docstitle=?, docsdescription=? WHERE id=? ");
            $stmt->bindValue(1, $_POST['docstitle']);
            $stmt->bindValue(2, $_POST['docsdescription']);
            $stmt->bindValue(3, $cid);
            $stmt->execute();

            if (isset($_FILES['document'])) {
                $d['file_name'] = $_FILES['document']['name'];
                $d['file_size'] = $_FILES['document']['size'];
                $d['file_tmp'] = $_FILES['document']['tmp_name'];
                $d['file_type'] = $_FILES['document']['type'];
                $d['file_ext'] = pathinfo($d['file_name'], PATHINFO_EXTENSION);

                if (is_uploaded_file($d['file_tmp'])) {
                    $uploadedfilename = mb_str_replace("-", "", genGUID()) . "." . $d['file_ext'];
                    move_uploaded_file($d['file_tmp'], "uploads/news/" . $uploadedfilename);

                    $stmt = $db->prepare("UPDATE cms_news SET docsname=?, docslink=? WHERE id=? ");
                    $stmt->bindValue(1, $d['file_name']);
                    $stmt->bindValue(2, $uploadedfilename);
                    $stmt->bindValue(3, $cid);
                    $stmt->execute();
                }
            }

            $this->res->redirect('admin/news/contentedit/' . $cid, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Notices Updated Successfully</div>');
        }

        $stmt = $db->prepare("SELECT * FROM cms_news WHERE id=? ");
        $stmt->bindValue(1, $cid);
        $stmt->execute();

        $content = $stmt->fetch();

        if ($content) {
            $data['content'] = $content;
            $this->res->display($data);
        } else {
            $this->res->redirect('admin/news/contentlist');
        }
    }

    public function admin_removefile($cid = 0) {
        $db = DB::getContext();

        $stmt = $db->prepare("UPDATE cms_news SET docsname=?, docslink=? WHERE id=? ");
        $stmt->bindValue(1, "");
        $stmt->bindValue(2, "");
        $stmt->bindValue(3, $cid);
        $stmt->execute();

        echo " ";
    }

}
