<?php

final class cDocs extends cAdminController {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $data['pagetitle'] = SITE_TITLE;
        $this->res->display($data);
    }

    public function admin_contentlist($cat = 0, $page_number = 1) {
        $data['pagename'] = 'Manage Documents';

        $db = DB::getContext();

        if ($cat != 0) {
            $csql = "SELECT COUNT(*) AS numrows FROM cms_docs WHERE category='$cat' ";
            $bsql = "SELECT * FROM cms_docs WHERE category='$cat' ORDER BY id DESC ";
        } else {
            $csql = "SELECT COUNT(*) AS numrows FROM cms_docs ";
            $bsql = "SELECT * FROM cms_docs ORDER BY id DESC ";
        }

        $stmt = $db->prepare($csql);
        $stmt->execute();
        $content = $stmt->fetch();

        $totalrows = $content->numrows;

        $total_pages = ceil($totalrows / PAGINATE_LIMIT);
        $page_position = (($page_number - 1) * PAGINATE_LIMIT); //get starting position to fetch the records

        //$cpage = $this->req->getCurrentPage();

        $data['paginatelink'] = paginate($page_number, $totalrows, $total_pages, 'admin/docs/contentlist');
        $data['pagenumber'] = $page_number;
        $data['setcat'] = $cat;

        $stmt = $db->prepare("$bsql LIMIT $page_position, " . PAGINATE_LIMIT);
        $stmt->execute();

        $data['contents'] = $stmt->fetchAll();

        $this->res->display($data);
    }

    public function admin_contentadd($cat = 0, $pno = 1) {
        $data['pagename'] = 'Manage Documents';
        $data['pno'] = $pno;
        $data['setcat'] = $cat;

        if ($this->req->isPost()) {
            $db = DB::getContext();

            $uploadedfilename = "";

            if (isset($_FILES['document'])) {
                $d['file_name'] = $_FILES['document']['name'];
                $d['file_size'] = $_FILES['document']['size'];
                $d['file_tmp'] = $_FILES['document']['tmp_name'];
                $d['file_type'] = $_FILES['document']['type'];
                $d['file_ext'] = pathinfo($d['file_name'], PATHINFO_EXTENSION);

                if (is_uploaded_file($d['file_tmp'])) {
                    $uploadedfilename = mb_str_replace("-", "", genGUID()) . "." . $d['file_ext'];
                    move_uploaded_file($d['file_tmp'], "uploads/documents/" . $uploadedfilename);

                    $stmt = $db->prepare("INSERT INTO cms_docs(category, docstitle, docsdescription, docsname, docslink, status) VALUES(?, ?, ?, ?, ?, ?) ");
                    $stmt->bindValue(1, $_POST['category']);
                    $stmt->bindValue(2, $_POST['docstitle']);
                    $stmt->bindValue(3, $_POST['docsdescription']);
                    $stmt->bindValue(4, $d['file_name']);
                    $stmt->bindValue(5, $uploadedfilename);
                    $stmt->bindValue(6, 0);
                    $stmt->execute();
                }
            }
            $this->res->redirect('admin/docs/contentadd/', '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Docs added Successfully</div>');
        }
        $this->res->display($data);
    }

    public function admin_contentedit($cid = 0) {
        $data['pagename'] = 'Manage Documents';

        $db = DB::getContext();

        if ($this->req->isPost()) {
            $uploadedfilename = "";

            $stmt = $db->prepare("UPDATE cms_docs SET category=?, docstitle=?, docsdescription=? WHERE id=? ");
            $stmt->bindValue(1, $_POST['category']);
            $stmt->bindValue(2, $_POST['docstitle']);
            $stmt->bindValue(3, $_POST['docsdescription']);
            $stmt->bindValue(4, $cid);
            $stmt->execute();

            if (isset($_FILES['document'])) {
                $d['file_name'] = $_FILES['document']['name'];
                $d['file_size'] = $_FILES['document']['size'];
                $d['file_tmp'] = $_FILES['document']['tmp_name'];
                $d['file_type'] = $_FILES['document']['type'];
                $d['file_ext'] = pathinfo($d['file_name'], PATHINFO_EXTENSION);

                if (is_uploaded_file($d['file_tmp'])) {
                    $uploadedfilename = mb_str_replace("-", "", genGUID()) . "." . $d['file_ext'];
                    move_uploaded_file($d['file_tmp'], "uploads/documents/" . $uploadedfilename);

                    $stmt = $db->prepare("UPDATE cms_docs SET docsname=?, docslink=? WHERE id=? ");
                    $stmt->bindValue(1, $d['file_name']);
                    $stmt->bindValue(2, $uploadedfilename);
                    $stmt->bindValue(3, $cid);
                    $stmt->execute();
                }
            }

            $this->res->redirect('admin/docs/contentedit/' . $cid, '<div style="font-size:13px; color:#ff0000; margin-bottom:4px; margin-top:8px;">Docs Updated Successfully</div>');
        }

        $stmt = $db->prepare("SELECT * FROM cms_docs WHERE id=? ");
        $stmt->bindValue(1, $cid);
        $stmt->execute();

        $content = $stmt->fetch();

        if ($content) {
            $data['content'] = $content;
            $this->res->display($data);
        } else {
            $this->res->redirect('admin/docs/contentlist');
        }
    }

    public function admin_removefile($cid = 0) {
        $db = DB::getContext();

        $stmt = $db->prepare("UPDATE cms_docs SET docsname=?, docslink=? WHERE id=? ");
        $stmt->bindValue(1, "");
        $stmt->bindValue(2, "");
        $stmt->bindValue(3, $cid);
        $stmt->execute();

        echo " ";
    }

}
