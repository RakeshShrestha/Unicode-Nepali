<?php

define('SITE_TITLE', 'Regional Urban Development Project (RUDP)');
define('PATH_PREFIX', serialize(array('admin', 'manage', 'ajax')));

define('SYSTEM_EMAIL', 'pddudbc@gmail.com');
define('SYSTEM_EMAIL2', 'dpd1dudbc@gmail.com');

define('PAGINATE_PUBLICLIMIT', '15');
define('PAGINATE_LIMIT', '30');

list($dbtype, $host, $user, $pass, $dbname) = unserialize(DB_CON);
define("DBmyNAME", $dbname);
